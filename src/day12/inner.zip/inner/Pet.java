package day12.inner;

//@FunctionalInterface -> 오류
public interface Pet {

    void eat();
    void play();
}
